<?php
/**
 * Test WordPress index file
 */

define('WP_USE_THEMES', true);
require('./wp-blog-header.php');
